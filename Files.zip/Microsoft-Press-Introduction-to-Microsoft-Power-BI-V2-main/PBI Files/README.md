# Microsoft-Press-Introduction-to-Microsoft-Power-BI-V2

Welcome to the Microsoft Press Introduction to Microsoft Power BI Second Edition source file repository.

This directory contains starter pbix files that correspond to the start of each lesson.
