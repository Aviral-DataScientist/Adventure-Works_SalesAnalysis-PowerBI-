# Microsoft-Press-Introduction-to-Microsoft-Power-BI-V2

Welcome to the Microsoft Press Introduction to Microsoft Power BI Second Edition source file repository. If you want to follow along with the demonstrations, follow these instructions:
1. Create a FOLDER on your C DRIVE named **Introduction to Power BI**. When you are done you should see **C:\Introduction to Power BI**
2. Click the green "Code" button near the top of this page and choose the "Download ZIP" option. This will create a zip file containing the necessary directories to your machine.
3. Once you have the zip file, extract all of the files from the zip file.
4. In the files that you just unzipped, navigate to folder named **Microsoft-Press-Introduction-to-Microsoft-Power-BI-V2-main**
5. Copy the following folders (Data, Lessons, Template) from that directory into the directory named **C:\Introduction to Power BI**
6. You now have all of the files you will need AND the same directory structure that is used in the source files.

If you are unable to create a folder named **C:\Introduction to Power BI** on your machine, you will need to find a location in which you can add the folder and follow the same steps as above. The issue you will have is that ALL of the Power BI files you will use will point to **C:\Introduction to Power BI** To fix this, you will need to adjust each Power BI file as you use them to your new directory structure. In the couese, we have a Lesson to teach you how to do this as file paths change all of the time in the data world.
